Worm.SymbOs.Velasco  --->  This is the real name


Download from:

    http://www.velasco.com.br


This is the first cellphone worm with source code available in the world !
Do you can modify, rename, delete, insert any code... 
only sent a .SIS installer to me :-)


    marcos@velasco.com.br
