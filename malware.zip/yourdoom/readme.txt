Virus name: W32.Yourdoom.A
functions: copyies to %system32%/yourdoom.exe, creates registry key, creates shitty files, overwrites 
the hosts file.  

i have loaded the package with icons to fool the user :) i do have icons that look like windows xp folder
but i have lost them :( please help me create a good virus with harvester/smtp server/dos component and or a
backdoor :)


~Bob[cZ].exe AKA Yourdoom[cZ]