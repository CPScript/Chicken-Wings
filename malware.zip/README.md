#########################
For education purpose only
Virus source code
##########################
malware code
